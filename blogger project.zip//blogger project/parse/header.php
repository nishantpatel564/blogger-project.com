    <header class="header background">
         <div class="logo">
          <img src="logo.png" alt="" />
          <!---add websitename--->
          <p class="websitename">tech info</p>
          <!---add website descripson--->
          <p class="descripson">learn new technology and science information</p>
        </div>
      <ul class="nav">
     
        <li class="menu"><a href="/blogger project/blogger.php">Home</a></li>
             <li class="menu"><a href="#">about</a></li>
                  <li class="menu"><a href="#">contact us</a></li>
      </ul>
    </header>